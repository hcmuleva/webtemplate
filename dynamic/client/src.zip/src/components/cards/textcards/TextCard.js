import React from 'react';

const TextCard = () => {
    return (
        <div>
            <h1>This is TextCard</h1>
        </div>
    );
};

export default TextCard;