import TextCard from "./TextCard";

export * from TextCard