import styled from "@emotion/styled";

export const Logo = styled.div`
    height: 72px;
    display: flex;
    justify-content: center;
    align-items: center;
`;