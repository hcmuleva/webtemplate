import React from 'react';

const OptionComponent = () => {
    return (
        <div>
            <h1>Option</h1>
        </div>
    );
};

export default OptionComponent;