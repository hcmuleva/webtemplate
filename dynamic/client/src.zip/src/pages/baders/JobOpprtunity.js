import React from 'react';

const JobOpprtunity = ({opprtunitylist}) => {
    console.log("opprtunitylist",opprtunitylist)
    return (
        <div>
            
        </div>
    );
};

export default JobOpprtunity;