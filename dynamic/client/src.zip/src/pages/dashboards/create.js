import React from 'react';

const DashboardCreate = () => {
    return (
        <div>
            <h1>Create</h1>
        </div>
    );
};

export default DashboardCreate;