import React from 'react';

const DashboardEdit = () => {
    return (
        <div>
            <h1>DashboardEdit</h1>
        </div>
    );
};

export default DashboardEdit;