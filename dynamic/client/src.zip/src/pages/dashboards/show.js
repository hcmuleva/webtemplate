import React from 'react';

const DashboardShow = () => {
    return (
        <div>
            <h1>DashboardShow</h1>
        </div>
    );
};

export default DashboardShow;